$ErrorActionPreference='Stop'
$sessionPath=$PSScriptRoot
$plan=Get-Content -LiteralPath (Join-Path $sessionPath 'pilot-01/plan.json') -Raw | ConvertFrom-Json
$begin=[DateTimeOffset]$plan.registeredUtc
$end=[DateTimeOffset]::UtcNow
$os=Get-CimInstance Win32_OperatingSystem
$before=Get-Content -LiteralPath (Join-Path $sessionPath 'host-before.json') -Raw | ConvertFrom-Json
$sameBoot=([DateTimeOffset]$before.LastBootUpTime).UtcTicks -eq ([DateTimeOffset]$os.LastBootUpTime).UtcTicks
[ordered]@{
    CapturedUtc=$end.ToString('o');LastBootUpTime=$os.LastBootUpTime.ToString('o');SameBootAsBefore=$sameBoot
    FreePhysicalMemoryKiB=[long]$os.FreePhysicalMemory;FreeVirtualMemoryKiB=[long]$os.FreeVirtualMemory
} | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $sessionPath 'host-after.json') -Encoding utf8
$complete=$true;$queryError=$null;$entries=@()
try {
    $events=Get-WinEvent -FilterHashtable @{LogName='System';StartTime=$begin.LocalDateTime;EndTime=$end.LocalDateTime;Id=41,4101} -ErrorAction Stop
    $entries=@($events | Where-Object {
        ($_.Id -eq 41 -and $_.ProviderName -eq 'Microsoft-Windows-Kernel-Power') -or
        ($_.Id -eq 4101 -and $_.ProviderName -eq 'Display')
    } | ForEach-Object { [ordered]@{Id=$_.Id;Provider=$_.ProviderName;TimeCreated=$_.TimeCreated.ToString('o');RecordId=$_.RecordId;Message=$_.Message} })
} catch {
    if ($_.FullyQualifiedErrorId -notlike 'NoMatchingEventsFound*') {$complete=$false;$queryError=$_.Exception.Message}
}
[ordered]@{
    StartUtc=$begin.UtcDateTime.ToString('o');EndUtc=$end.UtcDateTime.ToString('o');QueryCompleted=$complete
    QueryError=$queryError;SameBootAsBefore=$sameBoot;Entries=$entries
} | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $sessionPath 'system-events.json') -Encoding utf8
Get-Content -LiteralPath (Join-Path $sessionPath 'system-events.json')
