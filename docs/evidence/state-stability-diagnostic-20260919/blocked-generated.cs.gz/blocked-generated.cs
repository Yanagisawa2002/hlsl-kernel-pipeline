using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.Profiling;
using UnityEngine.Rendering;
using Debug = UnityEngine.Debug;

namespace HlslPerf.Crossover
{
    [Serializable] public sealed class Calibration
    {
        public int schema = 1, seed, agentCount, frames;
        public string sourceIdentity;
        public double targetVisibility, actualVisibilityMean;
        public float scale, fixedDelta = Options.FixedDelta, radius = Options.Radius, speed = Options.Speed;
        public float worldX = Options.WorldX, worldY = Options.WorldY;
        public View[] views;
    }
    [Serializable] public sealed class Sample
    {
        public ulong submissionId,resolvedSubmissionId,gpuTimestampT0,gpuTimestampT1,gpuTimestampT2,gpuTimestampFrequency,requiredFence,completedFence;
        public int timestampResolveDelayFrames=-1,timestampRingSlot=-1;
        public int globalFrameIndex,viewId,cycleIndex; public double submissionUtcMs,elapsedSeconds,availabilityUtcMs;
        public int frameIndex, visibleCount, submissionUnityFrame = -1, availabilityUnityFrame = -1;
        public double cpuCullAndListMs, cpuUploadMs, cpuSubmitMs, cpuTotalMs, updateIntervalMs;
        // -1 means unavailable, never zero-filled missing GPU measurements.
        public double gpuCullMs = -1, gpuDrawMs = -1, gpuRangeMs = -1;
    }
    [Serializable] public sealed class Check
    {
        public int frameIndex, cpuCount, gpuCount;
        public bool setEqual, imageEqual, nonEmptyImage;
        public string cpuImageSha256, gpuImageSha256;
    }
    [Serializable] public sealed class Result
    {
        public bool diagnosticOnly=true,eligibleForPerformanceAcceptance=false;
        public string arm,diagnosticIdentity; public double firstWorkloadTimestamp,diagnosticEndTimestamp,elapsedSeconds,warmupLastSubmissionTimestamp,warmupFencePassedTimestamp,firstMeasuredSubmissionTimestamp; public int framesExecuted,cyclesCompleted;
        public int schema = 105, protocolVersion = 0, processId, width = 1280, height = 720, vsync, targetFrameRate = -1;
        public string runId, pairId, mode, sourceIdentity, calibrationSha256, adapter, driver, graphicsApi, unityVersion, deviceVersion;
        public string buildConfiguration, cpu, os, error = "", gpuTimingStatus = "unavailable";
        public string cpuBaseline = "managed scalar single thread, fused predicate/list, no Burst/Jobs";
        public string visibleCountSource = "frozen full-sequence CPU oracle; selected frames checked on GPU in separate validation";
        public bool correctnessPassed, completed, gpuRecorderSupported, frameTimingEnabled;
        public bool endToEndComparable = false;
        public string nativeTimingBackend="D3D12 timestamp query",nativeTimingVersion="4",pluginSha256;
        public ulong timestampFrequency;
        public int timestampSubmitted,timestampResolved,timestampInvalid,maxRingOccupancy;
        public bool profilerEnabled;
        public string presentWaitStatus="unavailable";
        public string renderingThreadingMode;
        public string timingApi, timingLaunchMode;
        public bool supportsGraphicsFence, warmupFenceCompleted, batchFenceCompleted;
        public int firstMeasuredUnityFrame = -1, gpuMappedFrames;
        public long stopwatchFrequency, batchStartTicks, finalSubmissionTicks, lastFalseFencePollTicks, firstTrueFencePollTicks;
        public double batchCompletionMs = -1, batchCompletionMsPerFrame = -1, fenceObservationIntervalMs = -1, fenceObservationBoundMsPerFrame = -1;
        public double finalSubmissionToObservationMs = -1;
        public string endToEndCaveat = "Final-fence batch completion is a throughput/completion candidate, not individual-frame latency; requires external timing, pacing and quiet-pilot gates.";
        public Options options;
        public Sample[] samples = Array.Empty<Sample>();
        public Check[] checks = Array.Empty<Check>();
        public double actualVisibilityMean;
        public int gc0Collections;
    }

    public sealed class CrossoverBenchmark : MonoBehaviour
    {
        public ComputeShader culling;
        public Shader drawing;
        Options options; Calibration calibration; Result result;
        Agent[] population; uint[] cpuIds;
        ComputeBuffer agents, visible, args;
        Material material; RenderTexture target; CommandBuffer commands;
        NativeTimingBackend native; double initializationDeadline;
        GraphicsFence warmupFence, finalFence;
        bool warmupFenceInserted, finalFenceInserted;
        long warmupFenceSubmission, lastFencePoll;
        int mappedFrames;
        int nextFrame, drainFrames, initialGc; long lastUpdate;
        bool measuring, finished,diagnosticLastFrame; const int FrameCap=2000000; long firstWorkloadTick;
        static double UtcMs => (DateTime.UtcNow.Ticks-621355968000000000L)/10000.0;
        static readonly double TickMs = 1000.0 / Stopwatch.Frequency;
        static string Hash(byte[] bytes) { using (var sha = SHA256.Create()) return BitConverter.ToString(sha.ComputeHash(bytes)).Replace("-", "").ToLowerInvariant(); }
        static string Identity => Resources.Load<TextAsset>("crossover-source-identity").text.Trim();

        void Start()
        {
            try
            {
                options = Options.Parse(Environment.GetCommandLineArgs());
                if((options.mode!="cpu" && options.mode!="gpu") || options.agents!=100000 || options.frames!=1000 || options.warmup!=300 || options.timestamps!="on")throw new ArgumentException("State diagnostic contract");
                options.warmup=0;
                if (options.mode == "native-diagnostic") { gameObject.AddComponent<NativeTimingDiagnostic>().Initialize(options,culling,drawing); finished=true;return; }
                if (options.mode == "timing-diagnostic")
                {
                    gameObject.AddComponent<TimingDiagnostic>().Initialize(options, culling, drawing);
                    finished = true; return;
                }
                QualitySettings.vSyncCount = 0; Application.targetFrameRate = -1; Application.runInBackground = true;
                result = new Result { options = options, profilerEnabled=Profiler.enabled, pluginSha256=Resources.Load<TextAsset>("crossover-plugin-identity")?.text.Trim() ?? "unavailable", runId = options.runId, pairId = options.pairId, mode = options.mode,
                    arm=options.mode,diagnosticIdentity=Resources.Load<TextAsset>("state-diagnostic-identity").text.Trim(),
                    processId = Process.GetCurrentProcess().Id, sourceIdentity = Identity,
                    adapter = SystemInfo.graphicsDeviceName, driver = RuntimeDriver(), deviceVersion = SystemInfo.graphicsDeviceVersion,
                    renderingThreadingMode = SystemInfo.renderingThreadingMode.ToString(), graphicsApi = SystemInfo.graphicsDeviceType.ToString(), unityVersion = Application.unityVersion,
                    buildConfiguration = Debug.isDebugBuild ? "Development Mono, no script debugging/deep profiling" : "Release",
                    cpu = SystemInfo.processorType, os = SystemInfo.operatingSystem,
                    gpuRecorderSupported = SystemInfo.supportsGpuRecorder, frameTimingEnabled = FrameTimingManager.IsFeatureEnabled(),
                    supportsGraphicsFence = SystemInfo.supportsGraphicsFence, timingApi = options.timingApi,
                    timingLaunchMode = Application.isBatchMode ? "batchmode" : "normal", stopwatchFrequency = Stopwatch.Frequency };
                population = Model.Generate(options.agents, options.seed); cpuIds = new uint[options.agents];
                if (options.mode == "calibrate") { WriteCalibration(); return; }
                byte[] calibrationBytes = File.ReadAllBytes(options.calibration);
                calibration = JsonUtility.FromJson<Calibration>(System.Text.Encoding.UTF8.GetString(calibrationBytes));
                if (calibration.schema != 1 || calibration.seed != options.seed || calibration.agentCount != options.agents ||
                    calibration.frames != options.frames || calibration.targetVisibility != options.density || calibration.sourceIdentity != Identity ||
                    calibration.views.Length != options.frames) throw new InvalidOperationException("Calibration identity mismatch");
                result.calibrationSha256 = Hash(calibrationBytes); result.actualVisibilityMean = calibration.actualVisibilityMean;
                Allocate();
                if (options.mode == "validation") { StartCoroutine(ValidateSafe()); return; }
                if(options.timingApi!="native") throw new InvalidOperationException("Actual benchmark requires native timing");
                if(SystemInfo.graphicsDeviceType!=GraphicsDeviceType.Direct3D12 || Profiler.enabled) throw new InvalidOperationException("Require D3D12 without attached/startup profiler");
                if(!SystemInfo.supportsGraphicsFence) throw new NotSupportedException("GraphicsFence unavailable");
                result.mode="gpu-state-stability-diagnostic";result.samples = new Sample[FrameCap];
                native=new NativeTimingBackend(commands);initializationDeadline=Time.realtimeSinceStartupAsDouble+30;
                for (int f=0;f<FrameCap;f++) result.samples[f] = new Sample { frameIndex=f,globalFrameIndex=f,viewId=f%1000,cycleIndex=f/1000,visibleCount=calibration.views[f%1000].visible };
                nextFrame = -options.warmup; measuring = true;
            }
            catch (Exception e) { Fail(e); }
        }

        void Allocate()
        {
            if (!SystemInfo.supportsComputeShaders || SystemInfo.graphicsDeviceType == GraphicsDeviceType.Null)
                throw new NotSupportedException("A rendering GPU is required; do not use -nographics.");
            agents = new ComputeBuffer(options.agents, 28, ComputeBufferType.Structured); agents.SetData(population);
            visible = new ComputeBuffer(options.agents, 4, ComputeBufferType.Append);
            args = new ComputeBuffer(1, 16, ComputeBufferType.IndirectArguments); args.SetData(new uint[] {6, 0, 0, 0});
            material = new Material(drawing); material.SetBuffer("_Agents", agents); material.SetBuffer("_VisibleAgents", visible);
            culling.SetBuffer(0, "_Agents", agents); culling.SetBuffer(0, "_VisibleAgents", visible); culling.SetInt("_AgentCount", options.agents);
            var descriptor = new RenderTextureDescriptor(1280, 720) {
                graphicsFormat = UnityEngine.Experimental.Rendering.GraphicsFormat.R8G8B8A8_UNorm,
                depthStencilFormat = UnityEngine.Experimental.Rendering.GraphicsFormat.D32_SFloat,
                msaaSamples = 1, sRGB = false };
            target = new RenderTexture(descriptor); target.Create();
            if (!target.IsCreated()) throw new InvalidOperationException("Render target allocation failed");
            commands = new CommandBuffer { name = "Crossover offscreen" };
        }

        void WriteCalibration()
        {
            float scale = Model.Calibrate(population, options.frames, options.density);
            var c = new Calibration { seed = options.seed, agentCount = options.agents, frames = options.frames,
                targetVisibility = options.density, scale = scale, sourceIdentity = Identity, views = new View[options.frames] };
            long count = 0;
            for (int f = 0; f < options.frames; f++) { var v = Model.At(f, scale); v.visible = Model.Cull(population, v, cpuIds); c.views[f] = v; count += v.visible; }
            c.actualVisibilityMean = count / (double)(options.agents * (long)options.frames);
            Write(options.output, JsonUtility.ToJson(c, true)); finished = true; Application.Quit(0);
        }

        void Draw(string mode, View view, int measuredFrame, Sample sample)
        {
            long start = Stopwatch.GetTimestamp(); if(sample!=null && measuredFrame==0)result.batchStartTicks=start; int count = 0;
            if (mode == "cpu") count = Model.Cull(population, view, cpuIds);
            long culled = Stopwatch.GetTimestamp();
            if (mode == "cpu" && count > 0) visible.SetData(cpuIds, 0, 0, count);
            long uploaded = Stopwatch.GetTimestamp();
            if (mode == "cpu" && count != view.visible) throw new InvalidOperationException("CPU/calibration count disagreement");
            commands.Clear();
            commands.SetRenderTarget(target);
            // Unity converts this logical far depth for reversed-Z backends itself.
            commands.ClearRenderTarget(true, true, Color.black, 1f);
            commands.SetViewport(new Rect(0, 0, 1280, 720));
            var rect = new Vector4(view.x, view.y, view.halfX, view.halfY);
            material.SetVector("_ViewRect", rect);
            ulong id=0;
            if(native!=null && options.timestamps=="on") {id=native.Reserve();if(sample!=null) {sample.submissionId=id;sample.timestampRingSlot=(int)((id-1)%32);result.timestampSubmitted++;}native.Stamp(commands,id,0);}
            result.maxRingOccupancy=native==null?0:native.MaxOccupancy;
            if (mode == "gpu")
            {

                commands.SetBufferCounterValue(visible, 0);
                commands.SetComputeVectorParam(culling, "_ViewRect", rect);
                commands.DispatchCompute(culling, 0, (options.agents + 255) / 256, 1, 1);

            }
            if(id!=0) native.Stamp(commands,id,1);
            if(mode=="gpu") commands.CopyCounterValue(visible,args,4);
            if (mode == "gpu") commands.DrawProceduralIndirect(Matrix4x4.identity, material, 0, MeshTopology.Triangles, args);
            else if (count > 0) commands.DrawProcedural(Matrix4x4.identity, material, 0, MeshTopology.Triangles, 6, count);
            if(id!=0) native.Stamp(commands,id,2);
            if (native != null && nextFrame == 299)
            {
                warmupFence = commands.CreateGraphicsFence(GraphicsFenceType.AsyncQueueSynchronisation, SynchronisationStageFlags.AllGPUOperations);
                warmupFenceInserted = true;
            }
            if (native != null && diagnosticLastFrame)
            {
                finalFence = commands.CreateGraphicsFence(GraphicsFenceType.AsyncQueueSynchronisation, SynchronisationStageFlags.AllGPUOperations);
                finalFenceInserted = true;
            }
            sample.submissionUtcMs=UtcMs;
            if(firstWorkloadTick==0) {firstWorkloadTick=Stopwatch.GetTimestamp();result.firstWorkloadTimestamp=sample.submissionUtcMs;}
            sample.elapsedSeconds=(Stopwatch.GetTimestamp()-firstWorkloadTick)/(double)Stopwatch.Frequency;
            if(measuredFrame==299)result.warmupLastSubmissionTimestamp=sample.submissionUtcMs;
            if(measuredFrame==300)result.firstMeasuredSubmissionTimestamp=sample.submissionUtcMs;
            Graphics.ExecuteCommandBuffer(commands);
            long end = Stopwatch.GetTimestamp();
            if (native != null && nextFrame == 299) warmupFenceSubmission = end;
            if (finalFenceInserted && diagnosticLastFrame) { result.finalSubmissionTicks = end; lastFencePoll = end; }
            if (sample != null)
            {
                sample.cpuCullAndListMs = (culled - start) * TickMs;
                sample.cpuUploadMs = (uploaded - culled) * TickMs;
                sample.cpuSubmitMs = (end - uploaded) * TickMs; sample.cpuTotalMs = (end - start) * TickMs;
            }
        }

        void Update()
        {
            if (!measuring || finished) return;
            try
            {
                if(!native.Ready) {if(Time.realtimeSinceStartupAsDouble>initializationDeadline)throw new TimeoutException("Native initialization");return;}
                long now = Stopwatch.GetTimestamp();
                PollMappedTiming();
                if(warmupFenceInserted && result.warmupFencePassedTimestamp==0 && warmupFence.passed) {
                    result.warmupFencePassedTimestamp=UtcMs;result.warmupFenceCompleted=true;
                }
                if (diagnosticLastFrame)
                {
                    if (!finalFenceInserted) throw new InvalidOperationException("Missing final batch fence");
                    if (!result.batchFenceCompleted)
                    {
                        long pollStarted=Stopwatch.GetTimestamp();
                        if (finalFence.passed)
                        {
                            long observed = Stopwatch.GetTimestamp();
                            result.batchFenceCompleted = true; result.firstTrueFencePollTicks = observed;
                            result.batchCompletionMs = (observed - result.batchStartTicks) * TickMs;
                            result.batchCompletionMsPerFrame = result.batchCompletionMs / nextFrame;
                            result.fenceObservationIntervalMs = (observed - lastFencePoll) * TickMs;
                            long boundStart = result.lastFalseFencePollTicks > 0 ? result.lastFalseFencePollTicks : result.finalSubmissionTicks;
                            result.fenceObservationBoundMsPerFrame = (observed - boundStart) * TickMs / options.frames;
                            result.finalSubmissionToObservationMs = (observed - result.finalSubmissionTicks) * TickMs;
                            result.gc0Collections = GC.CollectionCount(0) - initialGc;
                        }
                        else { result.lastFalseFencePollTicks = pollStarted; lastFencePoll = result.lastFalseFencePollTicks; }
                        if ((now - result.finalSubmissionTicks) * TickMs > 30000) throw new InvalidOperationException("Batch fence timeout");
                    }
                    if ((options.timestamps=="off" || mappedFrames == nextFrame) && result.batchFenceCompleted) FinishTiming();
                    else if (++drainFrames > 120) throw new InvalidOperationException("Incomplete GPU samples during nonblocking drain");
                    return;
                }
                if(nextFrame>=FrameCap)throw new InvalidOperationException("Safety frame cap reached before30s");
                diagnosticLastFrame=firstWorkloadTick!=0 && (now-firstWorkloadTick)/(double)Stopwatch.Frequency>=30;
                int index=nextFrame%1000;
                if (nextFrame == 0)
                {
                    initialGc = GC.CollectionCount(0); result.firstMeasuredUnityFrame = Time.frameCount;

                }
                var sample = nextFrame < 0 ? null : result.samples[nextFrame];
                if (sample != null)
                {
                    sample.updateIntervalMs = (now - lastUpdate) * TickMs;
                    sample.submissionUnityFrame = Time.frameCount;
                }
                lastUpdate = now;
                Draw(options.mode, calibration.views[index], nextFrame, sample);
                nextFrame++;
            }
            catch (Exception e) { Fail(e); }
        }

        void PollMappedTiming()
        {
            if(options.timestamps=="off") return;
            while(native.TryRead(out ulong[] data)) {
                result.timestampFrequency=data[4];
                int index=checked((int)data[0]-1-options.warmup);if(index<0)continue;
                if(index>=FrameCap || index!=mappedFrames)throw new InvalidOperationException("Duplicate/missing resolution");
                var sample=result.samples[index];if(sample.submissionId!=data[0] || sample.resolvedSubmissionId!=0)throw new InvalidOperationException("Submission ID mismatch");
                sample.resolvedSubmissionId=data[0];sample.gpuTimestampT0=data[1];sample.gpuTimestampT1=data[2];sample.gpuTimestampT2=data[3];sample.gpuTimestampFrequency=data[4];sample.requiredFence=data[5];sample.completedFence=data[6];
                sample.gpuCullMs=options.mode=="cpu"?-1:(data[2]-data[1])*1000.0/data[4];sample.gpuDrawMs=(data[3]-data[2])*1000.0/data[4];sample.gpuRangeMs=(data[3]-data[1])*1000.0/data[4];
                sample.availabilityUtcMs=UtcMs;sample.availabilityUnityFrame=Time.frameCount;sample.timestampResolveDelayFrames=Time.frameCount-sample.submissionUnityFrame;
                mappedFrames++;result.timestampResolved=mappedFrames;result.gpuMappedFrames=mappedFrames;
            }
        }

        void FinishTiming()
        {
            result.gpuTimingStatus = options.timestamps=="off"?"disabled: overhead control":"complete: native explicit submission ID and completion fence";
            // The runner separately gates correctness, diagnostic proof, pacing, load and drift.
result.framesExecuted=nextFrame;result.cyclesCompleted=nextFrame/1000;result.diagnosticEndTimestamp=result.samples[nextFrame-1].submissionUtcMs;result.elapsedSeconds=result.samples[nextFrame-1].elapsedSeconds;Array.Resize(ref result.samples,nextFrame);
            result.completed = true; Finish(0);
        }

        IEnumerator ValidateSafe()
        {
            var iterator = Validate();
            while (true)
            {
                bool more;
                try { more = iterator.MoveNext(); }
                catch (Exception e) { Fail(e); yield break; }
                if (!more) yield break;
                yield return iterator.Current;
            }
        }
        IEnumerator Validate()
        {
            var checks = new List<Check>();
            foreach (int frame in Model.CheckFrames(options.frames))
            {
                var v = calibration.views[frame];
                Draw("cpu", v, -1, null);
                // Correctness-only synchronous readbacks, in a distinct process with no timing samples.
                byte[] cpuPixels = ReadImage(); int expectedCount = Model.Cull(population, v, cpuIds);
                Draw("gpu", v, -1, null);
                var argumentData = new uint[4]; args.GetData(argumentData);
                int gpuCount = checked((int)argumentData[1]);
                if (gpuCount > options.agents) { Fail(new InvalidOperationException("GPU count exceeds population")); yield break; }
                var ids = new uint[gpuCount]; if (gpuCount > 0) visible.GetData(ids, 0, 0, gpuCount);
                byte[] gpuPixels = ReadImage();
                var check = new Check { frameIndex = frame, cpuCount = expectedCount, gpuCount = gpuCount,
                    setEqual = Model.EqualSets(cpuIds, expectedCount, ids), cpuImageSha256 = Hash(cpuPixels), gpuImageSha256 = Hash(gpuPixels),
                    nonEmptyImage = HasColor(cpuPixels) };
                check.imageEqual = check.cpuImageSha256 == check.gpuImageSha256;
                checks.Add(check); result.checks = checks.ToArray();
                if (!check.setEqual || !check.imageEqual || !check.nonEmptyImage)
                { Fail(new InvalidOperationException("CPU/GPU set or image disagreement at frame " + frame)); yield break; }
                yield return null;
            }
            result.correctnessPassed = true; result.completed = true; Finish(0);
        }
        static bool HasColor(byte[] pixels) { for (int i = 0; i < pixels.Length; i += 4) if (pixels[i] != 0 || pixels[i+1] != 0 || pixels[i+2] != 0) return true; return false; }
        static string RuntimeDriver()
        {
            // Unity's graphicsDeviceVersion describes the API, not the installed driver.
            // The player writes its runtime-selected adapter driver before scene initialization.
            try {
                string text;
                using (var stream = new FileStream(Application.consoleLogPath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                using (var reader = new StreamReader(stream)) text = reader.ReadToEnd();
                var match = System.Text.RegularExpressions.Regex.Match(text, @"(?m)^\s*Driver:\s*([^\r\n]+)");
                return match.Success ? match.Groups[1].Value.Trim() : "unavailable (see external launch snapshot)";
            } catch (IOException) { return "unavailable (see external launch snapshot)"; }
        }
        byte[] ReadImage()
        {
            var previous = RenderTexture.active; RenderTexture.active = target;
            var texture = new Texture2D(1280, 720, TextureFormat.RGBA32, false, true);
            texture.ReadPixels(new Rect(0, 0, 1280, 720), 0, 0); texture.Apply();
            byte[] bytes = texture.GetRawTextureData<byte>().ToArray(); Destroy(texture); RenderTexture.active = previous;
            return bytes;
        }
        static void Write(string path, string json) { Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(path))); File.WriteAllText(path, json); }
        void Fail(Exception e)
        {
            Debug.LogException(e);
            if(result!=null && native!=null)result.timestampInvalid++;
            if (result == null) result = new Result(); result.error = e.ToString();
            Finish(2);
        }
        void Finish(int code)
        {
            finished = true; measuring = false;
            string json=JsonUtility.ToJson(result,false);
            json=System.Text.RegularExpressions.Regex.Replace(json,@"(""gpu(?:Cull|Draw|Range)Ms""\s*:\s*)-1(?:\.0)?(?=\s*[,}])","$1null");
            Write(options == null ? "argument-error.json" : options.output,json);
            Application.Quit(code);
        }
        void OnDestroy()
        {
            agents?.Release(); visible?.Release(); args?.Release(); commands?.Release();
            if (target != null) target.Release(); if (material != null) Destroy(material);
        }
    }
}
