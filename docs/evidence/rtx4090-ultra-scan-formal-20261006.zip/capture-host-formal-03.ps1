$ErrorActionPreference = 'Stop'
$sessionPath = $PSScriptRoot
$plan = Get-Content -LiteralPath (Join-Path $sessionPath 'gate-03/plan.json') -Raw | ConvertFrom-Json
$begin = [DateTimeOffset]$plan.registeredUtc
$end = [DateTimeOffset]::UtcNow
$os = Get-CimInstance Win32_OperatingSystem
$before = Get-Content -LiteralPath (Join-Path $sessionPath 'host-before-formal-03.json') -Raw | ConvertFrom-Json
$beforeBoot = [DateTimeOffset]$before.LastBootUpTime
$afterBoot = [DateTimeOffset]$os.LastBootUpTime
$hostRecord = [ordered]@{
    CapturedUtc = $end.ToString('o')
    LastBootUpTime = $os.LastBootUpTime.ToString('o')
    SameBootAsBefore = ($beforeBoot.UtcTicks -eq $afterBoot.UtcTicks)
    Version = $os.Version
    BuildNumber = $os.BuildNumber
    FreePhysicalMemoryKiB = [long]$os.FreePhysicalMemory
    FreeVirtualMemoryKiB = [long]$os.FreeVirtualMemory
}
$hostRecord | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $sessionPath 'host-after-formal-03.json') -Encoding utf8
$queryCompleted = $true
$queryError = $null
$entries = @()
try {
    $events = Get-WinEvent -FilterHashtable @{ LogName='System'; StartTime=$begin.LocalDateTime; EndTime=$end.LocalDateTime; Id=41,4101 } -ErrorAction Stop
    $entries = @($events | Where-Object {
        ($_.Id -eq 41 -and $_.ProviderName -eq 'Microsoft-Windows-Kernel-Power') -or
        ($_.Id -eq 4101 -and $_.ProviderName -eq 'Display')
    } | ForEach-Object {
        [ordered]@{ Id=$_.Id; Provider=$_.ProviderName; TimeCreated=$_.TimeCreated.ToString('o'); RecordId=$_.RecordId; Message=$_.Message }
    })
} catch {
    if ($_.FullyQualifiedErrorId -notlike 'NoMatchingEventsFound*') {
        $queryCompleted = $false
        $queryError = $_.Exception.Message
    }
}
$eventRecord = [ordered]@{
    StartUtc = $begin.ToString('o')
    EndUtc = $end.ToString('o')
    QueryCompleted = $queryCompleted
    QueryError = $queryError
    SameBootAsBefore = $hostRecord.SameBootAsBefore
    Entries = $entries
}
$eventRecord | ConvertTo-Json -Depth 6 | Set-Content -LiteralPath (Join-Path $sessionPath 'system-events-formal-03.json') -Encoding utf8
$eventRecord | ConvertTo-Json -Depth 6
