# Fluid scan scaling evidence, 2026-10-05

`accepted/sweep-02` has 16 processes, four per arm, each containing all 11 lengths.
`accepted/application-02` has 112 processes, four per arm at seven particle counts.
Plans precede execution; all raw CSV bytes remain unchanged. JSON directory and
command paths are redacted; inventory records both original and public hashes.

`invalid/sweep-01` preserves the entire earlier capacity-versus-length bug cohort.
Its invalid-attempt.json makes the analyzer reject it. Superseded-source gates and
pilots do not enter accepted curves. Application pilots are retained separately.

Recompute with the repository tools:

```powershell
$runs = Get-ChildItem accepted/sweep-02 -Directory | ForEach-Object { $_.FullName }
python C:/path/to/repo/tools/analyze_fluid_sweep.py $runs --output NEW_SCAN_JSON
python C:/path/to/repo/tools/analyze_fluid_application_scaling.py accepted/application-02 --output NEW_APP_JSON
```

Results distinguish per-operation sweep timings from three accumulated scan calls
per application frame. Core includes required reset and the entire scan algorithm.
All timestamps are source-frame associated; wall includes rendering/presentation.
No recordings are active. Pointwise four-process-pair intervals are unadjusted,
and unstable equal-key ordering/density-dependent physics limit causal claims.
