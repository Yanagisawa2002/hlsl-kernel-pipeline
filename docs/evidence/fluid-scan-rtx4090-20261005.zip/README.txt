Accepted visible Player cohort only: 9 performance processes, 3 standalone GPU gates, 3 offline visual exports.
Run/capture metadata is preserved except for settings.outputDirectory, replaced by the process name.
Original hashes and redactions are recorded in inventory.json. CSV and correctness/summary files are original bytes.
All failed/hidden/Recorder pilots are excluded. Local evidence retains complete launch commands and Player logs.
Static validation describes source compilation only, not execution; run/gate/capture receipts establish actual execution.
Videos and PNGs are separate local deliverables; video hashes/counts are in video-validation.json.
