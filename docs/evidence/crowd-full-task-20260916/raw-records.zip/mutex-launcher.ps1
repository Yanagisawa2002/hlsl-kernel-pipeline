$ErrorActionPreference = 'Stop'
$taskRoot = 'D:/CodexWork/hlsl-whole-task-20260915'
$taskMutex = [Threading.Mutex]::new($false, 'Local\CodexR9700VNextUnityGpu')
$held = $false
try {
    try { $held = $taskMutex.WaitOne(0) } catch [Threading.AbandonedMutexException] { $held = $true }
    if (!$held) { throw 'Hardware mutex is occupied; no workload started.' }
    if ((Get-CimInstance Win32_OperatingSystem).FreePhysicalMemory * 1024 -lt 4GB) { throw 'Insufficient available host memory.' }
    $env:HLSL_FIXED_MUTEX_OWNER = [string]$PID
    & 'C:/ProgramData/anaconda3/python.exe' -B "$taskRoot/.scratch/run_hlsl_shared_fixed.py" --protocol "$taskRoot/.scratch/focused-hlsl-protocol.json" --output "$taskRoot/.scratch/focused-shared-20260916-01"
    $taskExit = $LASTEXITCODE
}
finally {
    Remove-Item Env:HLSL_FIXED_MUTEX_OWNER -ErrorAction SilentlyContinue
    if ($held) { $taskMutex.ReleaseMutex() }
    $taskMutex.Dispose()
}
exit $taskExit
